#include "p2pentity.h"

#include <strings.h>

Define_Module(P2pentity);

void P2pentity::initialize()
{
    N_S = 0;   // Next transmitted
    N_A = -1;  // Last ack'ed
    N_R = 0;   // Next expected

    WindowSize = par("WindowSize");
    if (WindowSize < 1)
        throw cRuntimeError("Error: WindowSize parameter must be >0\n\n");

    FrameSize = par("FrameSize");
    if (FrameSize < 1)
        throw cRuntimeError("Error: FrameSize parameter must be >0\n\n");

    int roleparam = par("Role");
    switch (roleparam) {
    case 1:
        Role = TXRX;
        break;
    case 2:
        Role = TXONLY;
        break;
    case 3:
        Role = RXONLY;
        break;
    default:
        throw cRuntimeError("Error: Illegal value for Role (%d). Must be 1, 2 or 3\n\n", roleparam);
    }

    Timeout = par("Timeout");
    if (Timeout <= 0.0)
        throw cRuntimeError("Error: Timeout value must be > 0.0\n\n");

    // Parse the ARQ mode parameter. Currently only supports case-insensitive comparisons, but
    // alternative spellings (e.g., "Stop&Wait") could be considered in the future.
    std::string s = par("ARQMode").stdstringValue();
    if (strcasecmp(s.c_str(), "stop-and-wait") == 0) {
        EV << "Using Stop-and-Wait ARQ\n";
        ARQMode = 0; // Stop-and-wait
    } else if (strcasecmp(s.c_str(), "go-back-n") == 0) {
        EV << "Using Go-back-N ARQ\n";
        ARQMode = 1; // Go-back-N
    } else if (strcasecmp(s.c_str(), "selective-reject") == 0) {
        EV << "Using Selective-Reject ARQ\n";
        ARQMode = 2; // Selective-Reject
    } else {
        // EV_ERROR << "Unknown ARQMode = " << s << ", must be either Stop-and-wait, Go-back-N or Selective-Reject\n";
        throw cRuntimeError("Unknown ARQMode (\"%s\").\nValid values are \"Stop-and-wait\", \"Go-back-N\", or \"Selective-Reject\"\n\n", s.c_str());
    }

    verbose = ((int)par("Verbose") == 1);

    recoverymode = false;

    Priority = new cPacketQueue();
    OoSQueue = new cPacketQueue();   /// Queue for storing out-of-order messages

    kickstart = new cMessage("Kickstart", 1);
    txend = new cMessage("End of transmission", 2);

    throughput_sgnl = registerSignal("Throughput");
    utilisation_sgnl = registerSignal("Utilisation");

    receivedbits = 0;
    busystart = 0.0;
    busysum = 0.0;

    if ((Role == TXRX) || (Role == TXONLY))
        scheduleAt(exponential(0.1), kickstart);
}

void P2pentity::handleMessage(cMessage *msg)
{
    if (verbose) {
        switch (Role) {
        case TXRX:
            EV << "Combined: N_S = " << N_S << ", N_R = " << N_R << ", N_A = " << N_A << "\n";
            EV << "ReTXQueue: " << ReTXQueue.size() << ", Priority: " << Priority->getLength() << ", OoSQueue: " << OoSQueue->getLength() << "\n";
            break;
        case TXONLY:
            EV << "Sender: N_S = " << N_S << ", N_A = " << N_A << "\n";
            EV << "ReTXQueue: " << ReTXQueue.size() << ", Priority: " << Priority->getLength() << "\n";
            break;
        case RXONLY:
            EV << "Receiver: N_R = " << N_R << "\n";
            EV << "OoSQueue: " << OoSQueue->getLength() << "\n";
            break;
        default:
            throw cRuntimeError("Unknown role");
        }
    }

    if (msg->isSelfMessage()) {
        if ((msg->getKind() == 1) || (msg->getKind() == 2)) {

            if (msg->getKind() == 2) {
                busysum += simTime().dbl() - busystart;
                emit(utilisation_sgnl, busysum / simTime().dbl());
                busystart = -1.0;
            }

            if (Priority->isEmpty() == false) {
                dataframe * df = (dataframe *)Priority->pop();

                struct ReTXInfo * retxinfo = (struct ReTXInfo *)malloc(sizeof(struct ReTXInfo));
                retxinfo->df = df->dup();
                retxinfo->timer = new cMessage("Timeout", 3);
                scheduleAfter(Timeout, retxinfo->timer);
                ReTXQueue.push_back(retxinfo);

                send(df, "interface$o");
                busystart = simTime().dbl();

                scheduleAt(gate("interface$o")->findTransmissionChannel()->getTransmissionFinishTime(), txend);
            } else if (N_S - N_A <= WindowSize) {
                dataframe * df = new dataframe();
                df->setBitLength(FrameSize);
                df->setSeqNum(N_S);
                df->setAckNum(N_R);

                struct ReTXInfo * retxinfo = (struct ReTXInfo *)malloc(sizeof(struct ReTXInfo));
                retxinfo->df = df->dup();
                retxinfo->timer = new cMessage("Timeout", 3);
                scheduleAfter(Timeout, retxinfo->timer);
                ReTXQueue.push_back(retxinfo);

                send(df, "interface$o");
                busystart = simTime().dbl();

                N_S++;
                scheduleAt(gate("interface$o")->findTransmissionChannel()->getTransmissionFinishTime(), txend);
            }
        } else if (msg->getKind() == 3){
            // Timeout
            if (verbose)
                EV << "Timeout\n";

            for (std::vector<struct ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end();) {
                if (msg == (*it)->timer) {
                    Priority->insert((*it)->df);
                    delete (*it)->timer;
                    delete (*it);
                    ReTXQueue.erase(it);
                    break;
                }
            }
            if ((txend->isScheduled() == false) && (kickstart->isScheduled() == false))
                scheduleAfter(0, kickstart);
        } else {
            throw cRuntimeError("Unknown self-message received");
        }
    } else {
        if (msg->arrivedOn("interface$i")) {
            if (dynamic_cast<dataframe *>(msg) != nullptr) {
                dataframe * df = (dataframe *)msg;
                if (df->hasBitError() == false) {
                    if (verbose)
                        EV << "Received message with sequence number " << df->getSeqNum() << " and acknowledgement number " << df->getAckNum() << "\n";

                    if (df->getSeqNum() < N_R) {
                        ackframe * ack = new ackframe();
                        ack->setAckNum(N_R);
                        send(ack, "interface$o");

                        if (verbose)
                            EV << "Sending ACK with acknowledgement number " << N_R << " for duplicate message\n";

                        delete msg;
                    } else if (df->getSeqNum() == N_R) {
                        recoverymode = false;

                        receivedbits += df->getBitLength();

                        N_R++;

                        if (ARQMode == 2) {
                            bool done = (OoSQueue->getLength() == 0);
                            while ( !done ) {
                                bool found = false;
                                for (int i = 0; i < OoSQueue->getLength(); i++) {
                                    dataframe * dfstored = (dataframe *)OoSQueue->get(i);
                                    if (dfstored->getSeqNum() == N_R) {
                                        OoSQueue->remove(dfstored);
                                        receivedbits += dfstored->getBitLength();
                                        delete dfstored;
                                        N_R++;
                                        found = true;
                                        break;
                                    }
                                }
                                done = (OoSQueue->getLength() == 0) || (found == false);
                            }
                        }

                        ackframe * ack = new ackframe();
                        ack->setAckNum(N_R);
                        send(ack, "interface$o");

                        if (verbose)
                            EV << "Sending ACK with acknowledgement number " << N_R << "\n";

                        emit(throughput_sgnl, receivedbits / simTime().dbl());

                        delete msg;
                    } else if (df->getSeqNum() < N_R + WindowSize) {
                        if (ARQMode == 2) {
                            OoSQueue->insert(df);
                            if (verbose)
                                EV << "Buffering message with sequence number " << df->getSeqNum() << "\n";
                        } else {
                            if (verbose)
                                EV << "Ignoring message with sequence number " << df->getSeqNum() << "\n";
                            delete msg;
                        }
                        if (recoverymode == false) {
                            nackframe * nack = new nackframe();
                            nack->setAckNum(N_R);
                            send(nack, "interface$o");
                            if (verbose)
                                EV << "Sent NACK with N_R = " << N_R << "\n";
                        }
                        recoverymode = true;
                    } else {
                        throw cRuntimeError("Out-of-sequence message received with too large sequence number");
                    }
                } else {
                    if (verbose)
                        EV << "Received message with errors\n";
                    delete msg;
                }
            } else if (dynamic_cast<ackframe *>(msg) != nullptr) {
                ackframe * ack = (ackframe *)msg;
                if (ack->hasBitError() == false) {
                    if (verbose)
                        EV << "Received ACK with acknowledgement number " << ack->getAckNum() << "\n";

                    // Delete from retransmission queue
                    for (std::vector<struct ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end();) {
                        if (ack->getAckNum() > (*it)->df->getSeqNum()) {
                            cancelAndDelete((*it)->timer);
                            delete (*it)->df;
                            delete (*it);
                            it = ReTXQueue.erase(it);
                        } else {
                            it++;
                        }
                    }

                    if (ack->getAckNum() > N_A)
                        N_A = ack->getAckNum() - 1;

                    if ((txend->isScheduled() == false) && (kickstart->isScheduled() == false))
                        scheduleAfter(0, kickstart);
                } else {
                    if (verbose)
                        EV << "Received ACK with errors\n";
                }
                delete msg;
            } else if (dynamic_cast<nackframe *>(msg) != nullptr) {
                nackframe * nack = (nackframe *)msg;
                if (nack->hasBitError() == false) {

                    // Delete from retransmission queue
                    for (std::vector<struct ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end();) {
                        if (nack->getAckNum() > (*it)->df->getSeqNum()) {
                            if (verbose)
                                EV << "NACK: Acknowledging " << (*it)->df->getSeqNum() << "\n";
                            cancelAndDelete((*it)->timer);
                            delete (*it)->df;
                            delete (*it);
                            it = ReTXQueue.erase(it);
                        } else {
                            it++;
                        }
                    }

                    if (ARQMode == 1) {   // Go-back-N
                        int nxt = nack->getAckNum();
                        while (nxt < N_S) {
                            for (std::vector<ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end(); ) {
                                if ((*it)->df->getSeqNum() == nxt) {
                                    Priority->insert((*it)->df);
                                    if (verbose)
                                        EV << "NACK: Scheduling " << (*it)->df->getSeqNum() << " for retransmission\n";
                                    cancelAndDelete((*it)->timer);
                                    delete (*it);
                                    ReTXQueue.erase(it);
                                } else {
                                    ++it;
                                }
                            }
                            nxt++;
                        }
                        if ((txend->isScheduled() == false) && (kickstart->isScheduled() == false))
                            scheduleAfter(0, kickstart);
                    } else {   // Selective-Reject
                        int nxt = nack->getAckNum();
                        for (std::vector<ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end(); ) {
                            if ((*it)->df->getSeqNum() == nxt) {
                                Priority->insert((*it)->df);
                                if (verbose)
                                    EV << "NACK: Scheduling " << (*it)->df->getSeqNum() << " for retransmission\n";
                                cancelAndDelete((*it)->timer);
                                delete (*it);
                                ReTXQueue.erase(it);
                            } else {
                                ++it;
                            }
                        }
                        if ((txend->isScheduled() == false) && (kickstart->isScheduled() == false))
                            scheduleAfter(0, kickstart);
                    }
                } else {
                    if (verbose)
                        EV << "Received NACK with errors\n";
                }
                delete msg;
            } else {
                throw cRuntimeError("Packet with unknown format received");
            }
        }
    }
}

P2pentity::~P2pentity()
{
    cancelAndDelete(txend);
    cancelAndDelete(kickstart);

    for (std::vector<struct ReTXInfo *>::iterator it = ReTXQueue.begin(); it != ReTXQueue.end();) {
        struct ReTXInfo * retxinfo = (*it);
        cancelAndDelete(retxinfo->timer);
        delete retxinfo->df;
        delete retxinfo;
        it = ReTXQueue.erase(it);
    }
    delete OoSQueue;
    delete Priority;
}
